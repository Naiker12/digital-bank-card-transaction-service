"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.fillTemplate = exports.loadTemplate = void 0;
const client_s3_1 = require("@aws-sdk/client-s3");
const s3Client = new client_s3_1.S3Client({ region: process.env.AWS_REGION || "us-east-1" });
const BUCKET_NAME = "bank-notification-templates";
const loadTemplate = async (templateName) => {
    const key = `templates/${templateName}.html`;
    try {
        const command = new client_s3_1.GetObjectCommand({
            Bucket: BUCKET_NAME,
            Key: key,
        });
        const response = await s3Client.send(command);
        const template = await response.Body?.transformToString();
        if (!template) {
            throw new Error(`Template ${templateName} is empty`);
        }
        return template;
    }
    catch (error) {
        console.error(`Error loading template ${templateName}:`, error);
        throw error;
    }
};
exports.loadTemplate = loadTemplate;
const fillTemplate = (template, data) => {
    let filledTemplate = template;
    for (const [key, value] of Object.entries(data)) {
        const placeholder = new RegExp(`{{${key}}}`, "g");
        filledTemplate = filledTemplate.replace(placeholder, value);
    }
    return filledTemplate;
};
exports.fillTemplate = fillTemplate;
//# sourceMappingURL=templateLoader.js.map