"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.fillTemplate = exports.loadTemplate = void 0;
const client_s3_1 = require("@aws-sdk/client-s3");
const s3Client = new client_s3_1.S3Client({ region: process.env.AWS_REGION || "us-east-1" });
const BUCKET_NAME = process.env.TEMPLATE_BUCKET || "bank-notification-templates";
const loadTemplate = async (templateName) => {
    const fileName = `${templateName.toLowerCase().replace(".", "-")}.html`;
    const possibleKeys = [fileName, `templates/${fileName}`];
    for (const key of possibleKeys) {
        try {
            const command = new client_s3_1.GetObjectCommand({
                Bucket: BUCKET_NAME,
                Key: key,
            });
            const response = await s3Client.send(command);
            const template = await response.Body?.transformToString();
            if (template) {
                console.log(`Plantilla cargada con éxito desde S3: ${key}`);
                return template;
            }
        }
        catch (error) {
            if (error.Code === 'NoSuchKey' || error.name === 'NoSuchKey') {
                continue; // Probamos la siguiente ruta
            }
            console.error(`Error de red/permisos cargando plantilla ${key}:`, error);
            throw error;
        }
    }
    throw new Error(`La plantilla ${templateName} no se encontró en ninguna de las rutas: ${possibleKeys.join(", ")}`);
};
exports.loadTemplate = loadTemplate;
const fillTemplate = (template, data) => {
    let filledTemplate = template;
    for (const [key, value] of Object.entries(data)) {
        const placeholder = new RegExp(`{{${key}}}`, "g");
        filledTemplate = filledTemplate.replace(placeholder, value);
    }
    return filledTemplate;
};
exports.fillTemplate = fillTemplate;
//# sourceMappingURL=templateLoader.js.map