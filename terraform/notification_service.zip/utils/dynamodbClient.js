"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getUserEmail = exports.saveNotificationLog = void 0;
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const crypto_1 = require("crypto");
const client = new client_dynamodb_1.DynamoDBClient({ region: process.env.AWS_REGION || "us-east-1" });
const ddbDocClient = lib_dynamodb_1.DynamoDBDocumentClient.from(client);
const TABLE_NAME = "bank-notification-logs";
const USER_TABLE = process.env.USER_TABLE || "bank-users";
const saveNotificationLog = async (data) => {
    const params = {
        TableName: TABLE_NAME,
        Item: {
            notification_id: (0, crypto_1.randomUUID)(),
            user_id: data.userId,
            card_id: data.cardId,
            event_type: data.eventType,
            status: data.status,
            email: data.email,
            timestamp: new Date().toISOString(),
        },
    };
    try {
        await ddbDocClient.send(new lib_dynamodb_1.PutCommand(params));
        console.log(`Notification log saved for user ${data.userId}`);
    }
    catch (error) {
        console.error("Error saving notification log:", error);
    }
};
exports.saveNotificationLog = saveNotificationLog;
const getUserEmail = async (userId) => {
    if (!userId || userId === "unknown")
        return null;
    try {
        const response = await ddbDocClient.send(new lib_dynamodb_1.QueryCommand({
            TableName: USER_TABLE,
            KeyConditionExpression: "#uuid = :id",
            ExpressionAttributeNames: { "#uuid": "uuid" },
            ExpressionAttributeValues: { ":id": userId }
        }));
        if (response.Items && response.Items.length > 0) {
            return response.Items[0].email;
        }
    }
    catch (error) {
        console.error(`Error fetching email for user ${userId}:`, error);
    }
    return null;
};
exports.getUserEmail = getUserEmail;
//# sourceMappingURL=dynamodbClient.js.map