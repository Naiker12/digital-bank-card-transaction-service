"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.sqsClient = void 0;
const client_sqs_1 = require("@aws-sdk/client-sqs");
exports.sqsClient = new client_sqs_1.SQSClient({ region: process.env.AWS_REGION || "us-east-1" });
//# sourceMappingURL=sqsClient.js.map