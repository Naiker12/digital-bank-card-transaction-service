"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const emailService_1 = require("../services/emailService");
const dynamodbClient_1 = require("../utils/dynamodbClient");
const handler = async (event) => {
    console.log(`Procesando lote de ${event.Records.length} mensajes SQS.`);
    for (const record of event.Records) {
        try {
            console.log("Mensaje recibido:", record.body);
            const message = JSON.parse(record.body);
            const type = message.type || "NOTIFICATION";
            const data = message.data || {};
            let email = data.email || message.email;
            let userId = data.userId || message.userId || data.user_id || message.user_id;
            console.log(`Evento: ${type} | Usuario ID: ${userId} | Email Inicial: ${email}`);
            // 🔍 Recuperación resiliente de Email desde DynamoDB si no viene en el mensaje
            if (!email && userId && userId !== "unknown") {
                console.log(`Buscando email para userId: ${userId} en DynamoDB...`);
                email = await (0, dynamodbClient_1.getUserEmail)(userId);
                console.log(`Email recuperado: ${email}`);
            }
            if (!email) {
                console.warn(`[SKIP] No se encontró email para el evento ${type} (User: ${userId}). Ignorando.`);
                continue;
            }
            // Normalización del nombre de la plantilla
            const templateName = type.toLowerCase();
            console.log(`Intentando enviar correo a ${email} con plantilla: ${templateName}`);
            // Enviamos el correo
            await (0, emailService_1.sendEmail)(email, templateName, { ...message, ...data });
            console.log(`[SUCCESS] Correo enviado correctamente a ${email}`);
            // Guardamos log de éxito
            await (0, dynamodbClient_1.saveNotificationLog)({
                userId: String(userId || "unknown"),
                cardId: String(data.cardId || message.cardId || "unknown"),
                email: email,
                status: "SENT",
                eventType: type
            });
        }
        catch (error) {
            console.error("Error crítico procesando notificación individual:", error);
            // Si el error es de SES o S3, el catch de sendEmail ya lo habrá logueado, pero aquí capturamos cualquier otro fallo.
        }
    }
};
exports.handler = handler;
//# sourceMappingURL=sendNotification.js.map