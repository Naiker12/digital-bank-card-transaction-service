"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const emailService_1 = require("../services/emailService");
const dynamodbClient_1 = require("../utils/dynamodbClient");
const handler = async (event) => {
    console.log(`Processing batch of ${event.Records.length} SQS messages.`);
    for (const record of event.Records) {
        try {
            console.log("Message received:", record.body);
            const message = JSON.parse(record.body);
            const type = message.type || "NOTIFICATION";
            const data = message.data || {};
            let email = data.email || message.email;
            let userId = data.userId || message.userId || data.user_id || message.user_id;
            console.log(`Event: ${type} | User ID: ${userId} | Initial Email: ${email}`);
            // 1. Fetch email from DynamoDB if missing
            if (!email && userId && userId !== "unknown") {
                console.log(`Searching email for userId: ${userId} in DynamoDB...`);
                email = await (0, dynamodbClient_1.getUserEmail)(userId);
                console.log(`Email retrieved: ${email}`);
            }
            if (!email) {
                console.warn(`[SKIP] No email found for event ${type} (User: ${userId}). Ignoring.`);
                continue;
            }
            // 2. Normalize template name
            const templateName = type.toLowerCase();
            console.log(`Attempting to send email to ${email} using template: ${templateName}`);
            // 3. Send email via SES
            await (0, emailService_1.sendEmail)(email, templateName, { ...message, ...data });
            console.log(`[SUCCESS] Email sent successfully to ${email}`);
            // 4. Save success log
            await (0, dynamodbClient_1.saveNotificationLog)({
                userId: String(userId || "unknown"),
                cardId: String(data.cardId || message.cardId || "unknown"),
                email: email,
                status: "SENT",
                eventType: type
            });
        }
        catch (error) {
            console.error("Critical error processing notification record:", error);
        }
    }
};
exports.handler = handler;
//# sourceMappingURL=sendNotification.js.map