"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const emailService_1 = require("../services/emailService");
const dynamodbClient_1 = require("../utils/dynamodbClient");
const handler = async (event) => {
    for (const record of event.Records) {
        try {
            const message = JSON.parse(record.body);
            const { type, data } = message;
            // Extraer info de forma resiliente
            let email = (data && data.email) ? data.email : message.email;
            const userId = (data && data.userId) ? data.userId : message.userId;
            const cardId = (data && data.cardId) ? data.cardId : message.cardId;
            const eventType = type || message.eventType || "NOTIFICATION";
            // 🔍 Si no hay email, intentamos buscarlo en DynamoDB usando el userId
            if (!email && userId && userId !== "unknown") {
                console.log(`Email not found in payload for user ${userId}, searching in DynamoDB...`);
                email = await (0, dynamodbClient_1.getUserEmail)(userId);
            }
            let templateName = "default";
            switch (type) {
                case "WELCOME":
                    templateName = "welcome";
                    break;
                case "USER.LOGIN":
                    templateName = "login-alert";
                    break;
                case "USER.UPDATE":
                    templateName = "user-update";
                    break;
                case "CARD.CREATE":
                    templateName = "card-created";
                    break;
                case "CARD.ACTIVATE":
                    templateName = "card-activated";
                    break;
                case "TRANSACTION.PURCHASE":
                    templateName = "purchase-success";
                    break;
                case "TRANSACTION.SAVE":
                    templateName = "saving-success";
                    break;
                case "TRANSACTION.PAID":
                    templateName = "payment-success";
                    break;
                default:
                    if (message.eventType === "CARD_PURCHASE")
                        templateName = "purchase-success";
                    else if (message.eventType === "CARD_CREATED")
                        templateName = "card-created";
                    break;
            }
            if (email) {
                await (0, emailService_1.sendEmail)(email, templateName, data || message);
                console.log(`Email sent to ${email} for event ${eventType}`);
            }
            else {
                console.warn(`No email found for user ${userId}. skipping email send.`);
            }
            await (0, dynamodbClient_1.saveNotificationLog)({
                userId: userId || "unknown",
                cardId: cardId || "unknown",
                email: email || "unknown",
                status: email ? "SENT" : "FAILED",
                eventType: eventType
            });
        }
        catch (error) {
            console.error("Error processing record:", error);
        }
    }
};
exports.handler = handler;
//# sourceMappingURL=sendNotification.js.map