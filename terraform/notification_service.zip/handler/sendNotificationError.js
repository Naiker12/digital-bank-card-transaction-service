"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const dynamodbClient_1 = require("../utils/dynamodbClient");
const handler = async (event) => {
    for (const record of event.Records) {
        try {
            const message = JSON.parse(record.body);
            // New contract structure
            const { type, data } = message;
            const email = (data && data.email) ? data.email : message.email;
            const userId = (data && data.userId) ? data.userId : message.userId;
            const cardId = (data && data.cardId) ? data.cardId : message.cardId;
            console.error(`Processing failed notification for user ${userId || 'unknown'} from DLQ`);
            await (0, dynamodbClient_1.saveNotificationLog)({
                userId: userId || "unknown",
                cardId: cardId || "unknown",
                email: email || "unknown",
                status: "FAILED",
                eventType: type || message.eventType || "NOTIFICATION_ERROR"
            });
        }
        catch (error) {
            console.error("Error processing DLQ record:", error);
        }
    }
};
exports.handler = handler;
//# sourceMappingURL=sendNotificationError.js.map