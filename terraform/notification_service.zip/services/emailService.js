"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.sendEmail = void 0;
const client_ses_1 = require("@aws-sdk/client-ses");
const templateLoader_1 = require("../templates/templateLoader");
const sesClient = new client_ses_1.SESClient({ region: process.env.AWS_REGION || "us-east-1" });
const sendEmail = async (to, templateName, data) => {
    try {
        const rawTemplate = await (0, templateLoader_1.loadTemplate)(templateName);
        const htmlBody = (0, templateLoader_1.fillTemplate)(rawTemplate, data);
        const command = new client_ses_1.SendEmailCommand({
            Destination: {
                ToAddresses: [to],
            },
            Message: {
                Body: {
                    Html: {
                        Charset: "UTF-8",
                        Data: htmlBody,
                    },
                },
                Subject: {
                    Charset: "UTF-8",
                    Data: "Notificación Bancaria",
                },
            },
            Source: process.env.EMAIL_SOURCE || "no-reply@bank.com",
        });
        await sesClient.send(command);
        console.log(`Email sent to ${to} using template ${templateName}`);
    }
    catch (error) {
        console.error(`Error sending email to ${to}:`, error);
        throw error;
    }
};
exports.sendEmail = sendEmail;
//# sourceMappingURL=emailService.js.map